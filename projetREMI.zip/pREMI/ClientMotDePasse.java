import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

public class ClientMotDePasse extends JFrame {
    private IGestionnaireMotDePasse serveur;
    private String sessionUtilisateur;
    private JPanel panneauPrincipal;
    private CardLayout gestionnaireCarte;
    
    public ClientMotDePasse() {
        try {
            System.setProperty("javax.net.ssl.trustStore", "truststore.jks");
            System.setProperty("javax.net.ssl.trustStorePassword", "password");
            
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            serveur = (IGestionnaireMotDePasse) registry.lookup("GestionnaireMotDePasse");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Erreur de connexion au serveur");
            e.printStackTrace();
            System.exit(1);
        }
        
        initialiserInterface();
    }
    
    private void initialiserInterface() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            UIManager.put("Button.font", new Font("Arial", Font.PLAIN, 12));
            UIManager.put("Label.font", new Font("Arial", Font.PLAIN, 12));
            UIManager.put("TextField.font", new Font("Arial", Font.PLAIN, 12));
            UIManager.put("TextArea.font", new Font("Arial", Font.PLAIN, 12));
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        setTitle("Gestionnaire de Mots de Passe");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        
        gestionnaireCarte = new CardLayout();
        panneauPrincipal = new JPanel(gestionnaireCarte);
        
        panneauPrincipal.add(creerPanneauConnexion(), "connexion");
        panneauPrincipal.add(creerPanneauPrincipal(), "principal");
        panneauPrincipal.add(creerPanneauAjout(), "ajout");
        panneauPrincipal.add(creerPanneauListe(), "liste");
        
        add(panneauPrincipal);
        gestionnaireCarte.show(panneauPrincipal, "connexion");
    }
    
    private JPanel creerPanneauConnexion() {
        JPanel panneau = new JPanel(new GridBagLayout());
        panneau.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        
        JLabel titre = new JLabel("Gestionnaire de Mots de Passe");
        titre.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.insets = new Insets(20, 0, 30, 0);
        panneau.add(titre, gbc);
        
        gbc.gridwidth = 1; gbc.insets = new Insets(5, 10, 5, 10);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panneau.add(new JLabel("Nom d'utilisateur:"), gbc);
        
        JTextField champNom = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 1;
        panneau.add(champNom, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panneau.add(new JLabel("Mot de passe:"), gbc);
        
        JPasswordField champMotDePasse = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        panneau.add(champMotDePasse, gbc);
        
        JButton boutonConnexion = new JButton("Se connecter");
        boutonConnexion.setBackground(new Color(70, 130, 180));
        boutonConnexion.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3; gbc.insets = new Insets(20, 10, 5, 10);
        panneau.add(boutonConnexion, gbc);
        
        JButton boutonInscription = new JButton("S'inscrire");
        boutonInscription.setBackground(new Color(34, 139, 34));
        boutonInscription.setForeground(Color.WHITE);
        gbc.gridx = 1; gbc.gridy = 3;
        panneau.add(boutonInscription, gbc);
        
        boutonConnexion.addActionListener(e -> {
            try {
                String session = serveur.connecter(champNom.getText(), new String(champMotDePasse.getPassword()));
                if (session != null) {
                    sessionUtilisateur = session;
                    gestionnaireCarte.show(panneauPrincipal, "principal");
                } else {
                    JOptionPane.showMessageDialog(this, "Nom d'utilisateur ou mot de passe incorrect");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur de connexion");
            }
        });
        
        boutonInscription.addActionListener(e -> {
            try {
                if (serveur.inscrire(champNom.getText(), new String(champMotDePasse.getPassword()))) {
                    JOptionPane.showMessageDialog(this, "Inscription réussie! Vous pouvez maintenant vous connecter.");
                } else {
                    JOptionPane.showMessageDialog(this, "Nom d'utilisateur déjà existant");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur d'inscription");
            }
        });
        
        return panneau;
    }
    
    private JPanel creerPanneauPrincipal() {
        JPanel panneau = new JPanel(new GridBagLayout());
        panneau.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        
        JLabel titre = new JLabel("Menu Principal");
        titre.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.insets = new Insets(20, 0, 30, 0);
        panneau.add(titre, gbc);
        
        JButton boutonAjouter = new JButton("Ajouter un mot de passe");
        boutonAjouter.setPreferredSize(new Dimension(200, 40));
        boutonAjouter.setBackground(new Color(70, 130, 180));
        boutonAjouter.setForeground(Color.WHITE);
        gbc.gridy = 1; gbc.insets = new Insets(10, 0, 10, 0);
        panneau.add(boutonAjouter, gbc);
        
        JButton boutonAfficher = new JButton("Afficher mes comptes");
        boutonAfficher.setPreferredSize(new Dimension(200, 40));
        boutonAfficher.setBackground(new Color(34, 139, 34));
        boutonAfficher.setForeground(Color.WHITE);
        gbc.gridy = 2;
        panneau.add(boutonAfficher, gbc);
        
        JButton boutonDeconnexion = new JButton("Déconnexion");
        boutonDeconnexion.setPreferredSize(new Dimension(200, 40));
        boutonDeconnexion.setBackground(new Color(178, 34, 34));
        boutonDeconnexion.setForeground(Color.WHITE);
        gbc.gridy = 3;
        panneau.add(boutonDeconnexion, gbc);
        
        boutonAjouter.addActionListener(e -> gestionnaireCarte.show(panneauPrincipal, "ajout"));
        boutonAfficher.addActionListener(e -> {
            rafraichirListeComptes();
            gestionnaireCarte.show(panneauPrincipal, "liste");
        });
        boutonDeconnexion.addActionListener(e -> {
            sessionUtilisateur = null;
            gestionnaireCarte.show(panneauPrincipal, "connexion");
        });
        
        return panneau;
    }
    
    private JPanel creerPanneauAjout() {
        JPanel panneau = new JPanel(new GridBagLayout());
        panneau.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        
        JLabel titre = new JLabel("Ajouter un compte");
        titre.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; gbc.insets = new Insets(20, 0, 20, 0);
        panneau.add(titre, gbc);
        
        gbc.gridwidth = 1; gbc.insets = new Insets(5, 10, 5, 10);
        
        gbc.gridx = 0; gbc.gridy = 1;
        panneau.add(new JLabel("Service:"), gbc);
        
        JTextField champService = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 1;
        panneau.add(champService, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        panneau.add(new JLabel("Nom d'utilisateur:"), gbc);
        
        JTextField champNomUtilisateur = new JTextField(20);
        gbc.gridx = 1; gbc.gridy = 2;
        panneau.add(champNomUtilisateur, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        panneau.add(new JLabel("Mot de passe:"), gbc);
        
        JPasswordField champMotDePasse = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        panneau.add(champMotDePasse, gbc);
        
        JButton boutonAjouter = new JButton("Ajouter");
        boutonAjouter.setBackground(new Color(70, 130, 180));
        boutonAjouter.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 4; gbc.insets = new Insets(20, 10, 5, 10);
        panneau.add(boutonAjouter, gbc);
        
        JButton boutonRetour = new JButton("Retour");
        boutonRetour.setBackground(new Color(128, 128, 128));
        boutonRetour.setForeground(Color.WHITE);
        gbc.gridx = 1; gbc.gridy = 4;
        panneau.add(boutonRetour, gbc);
        
        boutonAjouter.addActionListener(e -> {
            try {
                if (serveur.ajouterCompte(sessionUtilisateur, champService.getText(), 
                                        champNomUtilisateur.getText(), new String(champMotDePasse.getPassword()))) {
                    JOptionPane.showMessageDialog(this, "Compte ajouté avec succès!");
                    champService.setText("");
                    champNomUtilisateur.setText("");
                    champMotDePasse.setText("");
                    gestionnaireCarte.show(panneauPrincipal, "principal");
                } else {
                    JOptionPane.showMessageDialog(this, "Erreur lors de l'ajout");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur de communication");
            }
        });
        
        boutonRetour.addActionListener(e -> gestionnaireCarte.show(panneauPrincipal, "principal"));
        
        return panneau;
    }
    
    private JPanel creerPanneauListe() {
        JPanel panneau = new JPanel(new BorderLayout());
        panneau.setBackground(Color.WHITE);
        
        JPanel panneauHaut = new JPanel(new FlowLayout());
        panneauHaut.setBackground(Color.WHITE);
        
        JTextField champRecherche = new JTextField(20);
        JButton boutonRechercher = new JButton("Rechercher");
        boutonRechercher.setBackground(new Color(70, 130, 180));
        boutonRechercher.setForeground(Color.WHITE);
        
        panneauHaut.add(new JLabel("Recherche:"));
        panneauHaut.add(champRecherche);
        panneauHaut.add(boutonRechercher);
        
        String[] colonnes = {"Service", "Nom d'utilisateur", "Mot de passe", "Actions"};
        DefaultTableModel modeleTableau = new DefaultTableModel(colonnes, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 3;
            }
        };
        
        JTable tableau = new JTable(modeleTableau) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 3 ? JPanel.class : Object.class;
            }
        };
        
        tableau.setRowHeight(40);
        
        // Correction ici: utilisation de DefaultTableCellRenderer pour la colonne des actions
        tableau.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, 
                    boolean isSelected, boolean hasFocus, int row, int column) {
                if (value instanceof Component) {
                    return (Component) value;
                }
                return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            }
        });
        
        tableau.getColumnModel().getColumn(3).setCellEditor(new DefaultCellEditor(new JCheckBox()) {
            @Override
            public Component getTableCellEditorComponent(JTable table, Object value, 
                    boolean isSelected, int row, int column) {
                if (value instanceof Component) {
                    return (Component) value;
                }
                return super.getTableCellEditorComponent(table, value, isSelected, row, column);
            }
        });
        
        JScrollPane scrollPane = new JScrollPane(tableau);
        
        JPanel panneauBas = new JPanel(new FlowLayout());
        panneauBas.setBackground(Color.WHITE);
        
        JButton boutonRetour = new JButton("Retour au menu");
        boutonRetour.setBackground(new Color(128, 128, 128));
        boutonRetour.setForeground(Color.WHITE);
        panneauBas.add(boutonRetour);
        
        panneau.add(panneauHaut, BorderLayout.NORTH);
        panneau.add(scrollPane, BorderLayout.CENTER);
        panneau.add(panneauBas, BorderLayout.SOUTH);
        
        boutonRechercher.addActionListener(e -> {
            try {
                String recherche = champRecherche.getText().trim();
                List<CompteService> comptes;
                if (recherche.isEmpty()) {
                    comptes = serveur.obtenirComptes(sessionUtilisateur);
                } else {
                    comptes = serveur.rechercherComptes(sessionUtilisateur, recherche);
                }
                remplirTableau(modeleTableau, comptes);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur de recherche");
            }
        });
        
        boutonRetour.addActionListener(e -> gestionnaireCarte.show(panneauPrincipal, "principal"));
        
        panneau.putClientProperty("modeleTableau", modeleTableau);
        
        return panneau;
    }
    
    private void rafraichirListeComptes() {
        try {
            JPanel panneauListe = (JPanel) panneauPrincipal.getComponent(3);
            DefaultTableModel modele = (DefaultTableModel) panneauListe.getClientProperty("modeleTableau");
            List<CompteService> comptes = serveur.obtenirComptes(sessionUtilisateur);
            remplirTableau(modele, comptes);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement des comptes");
        }
    }
    
    private void remplirTableau(DefaultTableModel modele, List<CompteService> comptes) {
        modele.setRowCount(0);
        for (CompteService compte : comptes) {
            JButton voirBtn = new JButton("Voir");
            JButton modifierBtn = new JButton("Modifier");
            JButton supprimerBtn = new JButton("Supprimer");
            
            voirBtn.addActionListener(e -> {
                try {
                    String mdp = serveur.dechiffrerMotDePasse(sessionUtilisateur, compte.id);
                    JOptionPane.showMessageDialog(this, 
                        "Service: " + compte.service + "\n" +
                        "Utilisateur: " + compte.nomUtilisateur + "\n" +
                        "Mot de passe: " + mdp);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Erreur lors de la récupération");
                }
            });
            
            modifierBtn.addActionListener(e -> {
                JPanel panel = new JPanel(new GridLayout(4, 2));
                JTextField serviceField = new JTextField(compte.service);
                JTextField userField = new JTextField(compte.nomUtilisateur);
                JPasswordField passField = new JPasswordField();
                
                panel.add(new JLabel("Service:"));
                panel.add(serviceField);
                panel.add(new JLabel("Utilisateur:"));
                panel.add(userField);
                panel.add(new JLabel("Nouveau mot de passe:"));
                panel.add(passField);
                
                int result = JOptionPane.showConfirmDialog(this, panel, 
                    "Modifier le compte", JOptionPane.OK_CANCEL_OPTION);
                
                if (result == JOptionPane.OK_OPTION) {
                    try {
                        boolean success = serveur.modifierCompte(sessionUtilisateur, 
                            compte.id, 
                            serviceField.getText(), 
                            userField.getText(), 
                            new String(passField.getPassword()));
                        
                        if (success) {
                            JOptionPane.showMessageDialog(this, "Compte modifié avec succès");
                            rafraichirListeComptes();
                        } else {
                            JOptionPane.showMessageDialog(this, "Erreur lors de la modification");
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Erreur de communication");
                    }
                }
            });
            
            supprimerBtn.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(this, 
                    "Voulez-vous vraiment supprimer ce compte?", 
                    "Confirmation", JOptionPane.YES_NO_OPTION);
                
                if (confirm == JOptionPane.YES_OPTION) {
                    try {
                        boolean success = serveur.supprimerCompte(sessionUtilisateur, compte.id);
                        if (success) {
                            JOptionPane.showMessageDialog(this, "Compte supprimé avec succès");
                            rafraichirListeComptes();
                        } else {
                            JOptionPane.showMessageDialog(this, "Erreur lors de la suppression");
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, "Erreur de communication");
                    }
                }
            });
            
            JPanel actionsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 0));
            actionsPanel.add(voirBtn);
            actionsPanel.add(modifierBtn);
            actionsPanel.add(supprimerBtn);
            
            modele.addRow(new Object[]{
                compte.service,
                compte.nomUtilisateur,
                "••••••••",
                actionsPanel
            });
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new ClientMotDePasse().setVisible(true);
        });
    }
}
