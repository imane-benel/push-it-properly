import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.io.PrintStream;
import java.awt.BorderLayout;

// Interface RMI
interface IGestionnaireMotDePasse extends Remote {
    boolean inscrire(String nomUtilisateur, String motDePasse) throws RemoteException;
    String connecter(String nomUtilisateur, String motDePasse) throws RemoteException;
    boolean ajouterCompte(String session, String service, String nomUtilisateur, String motDePasse) throws RemoteException;
    java.util.List<CompteService> obtenirComptes(String session) throws RemoteException;
    boolean modifierCompte(String session, int id, String service, String nomUtilisateur, String motDePasse) throws RemoteException;
    boolean supprimerCompte(String session, int id) throws RemoteException;
    String dechiffrerMotDePasse(String session, int id) throws RemoteException;
    java.util.List<CompteService> rechercherComptes(String session, String recherche) throws RemoteException;
}

// Classe pour représenter un compte de service
class CompteService implements Serializable {
    public int id;
    public String service;
    public String nomUtilisateur;
    public String motDePasseChiffre;
    
    public CompteService(int id, String service, String nomUtilisateur, String motDePasseChiffre) {
        this.id = id;
        this.service = service;
        this.nomUtilisateur = nomUtilisateur;
        this.motDePasseChiffre = motDePasseChiffre;
    }
}

// Implémentation du serveur
public class ServeurMotDePasse extends UnicastRemoteObject implements IGestionnaireMotDePasse {
    private Map<String, String> utilisateurs = new ConcurrentHashMap<>();
    private Map<String, String> sessions = new ConcurrentHashMap<>();
    private Map<String, java.util.List<CompteService>> comptesUtilisateurs = new ConcurrentHashMap<>();
    private int prochainId = 1;
    private SecretKey cleAES;
    
    public ServeurMotDePasse() throws RemoteException {
        super();
        try {
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(256);
            cleAES = keyGen.generateKey();
            creerInterfaceServeur();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void creerInterfaceServeur() {
        JFrame frame = new JFrame("Serveur Gestionnaire de Mots de Passe");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        
        JTextArea logArea = new JTextArea();
        logArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(logArea);
        
        JButton clearButton = new JButton("Effacer les logs");
        clearButton.addActionListener(e -> logArea.setText(""));
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(clearButton, BorderLayout.SOUTH);
        
        frame.add(panel);
        frame.setVisible(true);
        
        PrintStream printStream = new PrintStream(new CustomOutputStream(logArea));
        System.setOut(printStream);
        System.setErr(printStream);
    }
    
    class CustomOutputStream extends OutputStream {
        private JTextArea textArea;
        
        public CustomOutputStream(JTextArea textArea) {
            this.textArea = textArea;
        }
        
        @Override
        public void write(int b) throws IOException {
            textArea.append(String.valueOf((char) b));
            textArea.setCaretPosition(textArea.getDocument().getLength());
        }
    }
    
    private String hacherMotDePasse(String motDePasse) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(motDePasse.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            return null;
        }
    }
    
    private String chiffrerAES(String texte) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, cleAES);
            byte[] encrypted = cipher.doFinal(texte.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            return null;
        }
    }
    
    private String dechiffrerAES(String texteChiffre) {
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, cleAES);
            byte[] decoded = Base64.getDecoder().decode(texteChiffre);
            byte[] decrypted = cipher.doFinal(decoded);
            return new String(decrypted);
        } catch (Exception e) {
            return null;
        }
    }
    
    @Override
    public boolean inscrire(String nomUtilisateur, String motDePasse) throws RemoteException {
        if (utilisateurs.containsKey(nomUtilisateur)) {
            return false;
        }
        utilisateurs.put(nomUtilisateur, hacherMotDePasse(motDePasse));
        comptesUtilisateurs.put(nomUtilisateur, new ArrayList<>());
        System.out.println("Nouvel utilisateur inscrit: " + nomUtilisateur);
        return true;
    }
    
    @Override
    public String connecter(String nomUtilisateur, String motDePasse) throws RemoteException {
        String motDePasseHache = hacherMotDePasse(motDePasse);
        if (utilisateurs.containsKey(nomUtilisateur) && 
            utilisateurs.get(nomUtilisateur).equals(motDePasseHache)) {
            String session = UUID.randomUUID().toString();
            sessions.put(session, nomUtilisateur);
            System.out.println("Utilisateur connecté: " + nomUtilisateur);
            return session;
        }
        System.out.println("Tentative de connexion échouée pour: " + nomUtilisateur);
        return null;
    }
    
    @Override
    public boolean ajouterCompte(String session, String service, String nomUtilisateur, String motDePasse) throws RemoteException {
        String utilisateur = sessions.get(session);
        if (utilisateur == null) return false;
        
        String motDePasseChiffre = chiffrerAES(motDePasse);
        CompteService nouveau = new CompteService(prochainId++, service, nomUtilisateur, motDePasseChiffre);
        comptesUtilisateurs.get(utilisateur).add(nouveau);
        System.out.println("Nouveau compte ajouté pour " + utilisateur + " - Service: " + service);
        return true;
    }
    
    @Override
    public java.util.List<CompteService> obtenirComptes(String session) throws RemoteException {
        String utilisateur = sessions.get(session);
        if (utilisateur == null) return new ArrayList<>();
        return new ArrayList<>(comptesUtilisateurs.get(utilisateur));
    }
    
    @Override
    public boolean modifierCompte(String session, int id, String service, String nomUtilisateur, String motDePasse) throws RemoteException {
        String utilisateur = sessions.get(session);
        if (utilisateur == null) return false;
        
        java.util.List<CompteService> comptes = comptesUtilisateurs.get(utilisateur);
        for (CompteService compte : comptes) {
            if (compte.id == id) {
                compte.service = service;
                compte.nomUtilisateur = nomUtilisateur;
                compte.motDePasseChiffre = chiffrerAES(motDePasse);
                System.out.println("Compte modifié pour " + utilisateur + " - ID: " + id);
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean supprimerCompte(String session, int id) throws RemoteException {
        String utilisateur = sessions.get(session);
        if (utilisateur == null) return false;
        
        java.util.List<CompteService> comptes = comptesUtilisateurs.get(utilisateur);
        boolean removed = comptes.removeIf(compte -> compte.id == id);
        if (removed) {
            System.out.println("Compte supprimé pour " + utilisateur + " - ID: " + id);
        }
        return removed;
    }
    
    @Override
    public String dechiffrerMotDePasse(String session, int id) throws RemoteException {
        String utilisateur = sessions.get(session);
        if (utilisateur == null) return null;
        
        java.util.List<CompteService> comptes = comptesUtilisateurs.get(utilisateur);
        for (CompteService compte : comptes) {
            if (compte.id == id) {
                System.out.println("Mot de passe déchiffré pour " + utilisateur + " - Service: " + compte.service);
                return dechiffrerAES(compte.motDePasseChiffre);
            }
        }
        return null;
    }
    
    @Override
    public java.util.List<CompteService> rechercherComptes(String session, String recherche) throws RemoteException {
        String utilisateur = sessions.get(session);
        if (utilisateur == null) return new ArrayList<>();
        
        java.util.List<CompteService> comptes = comptesUtilisateurs.get(utilisateur);
        java.util.List<CompteService> resultats = new ArrayList<>();
        for (CompteService compte : comptes) {
            if (compte.service.toLowerCase().contains(recherche.toLowerCase()) ||
                compte.nomUtilisateur.toLowerCase().contains(recherche.toLowerCase())) {
                resultats.add(compte);
            }
        }
        return resultats;
    }
    
    public static void main(String[] args) {
        try {
            System.setProperty("javax.net.ssl.keyStore", "keystore.jks");
            System.setProperty("javax.net.ssl.keyStorePassword", "password");
            
            ServeurMotDePasse serveur = new ServeurMotDePasse();
            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("GestionnaireMotDePasse", serveur);
            
            System.out.println("Serveur démarré sur le port 1099");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
