package metier;

public class CpmteEpargne extends Compte {
    private float tauxInteret ;

    public CpmteEpargne(float s, float tauxInteret) {
        super(s);
        this.tauxInteret = tauxInteret;
    }

    public void calculInteret() {
        float interet = getSolde() * tauxInteret / 100;
        verser(interet);
              }

    @Override
    public String toString() {
        return super.toString() + " Taux d'intérêt=" + tauxInteret + "%";
    }
}
