package metier;

public class CompteSimple  extends Compte{
    public float decouvert;
    public CompteSimple(float s ,float decouvert) {
        super(s);
        this.decouvert = decouvert;
    }
    public void retirer (float mt) {
        if(getSolde()-mt >= -decouvert) {
            super.retirer(mt);
            System.out.println("Retrait fait ");
        }
        else {
            System.out.println("Impossible de retirer");
        }
    }
    public String toString() {
        return super.toString() + "decouvert=" + decouvert;
    }

}
