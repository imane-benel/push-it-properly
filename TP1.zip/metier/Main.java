package metier  ;

import metier.Compte;
import metier.CompteSimple;
import metier.CpmteEpargne;
import metier.ComptePayant;

public class Main {
    public static void main(String[] args) {

        System.out.println("=== Test Compte ===");
        Compte c1 = new Compte(500);
        c1.verser(200);
        c1.retirer(100);
        System.out.println(c1);

        System.out.println("\n=== Test Compte Simple ===");
        CompteSimple cs = new CompteSimple(100, 300); // solde = 100, découvert = 300
        cs.retirer(350); // autorisé
        cs.retirer(100); // refusé
        cs.verser(200);
        System.out.println(cs);

        System.out.println("\n=== Test Compte Epargne ===");
        CpmteEpargne ce = new CpmteEpargne(1000, 2.5f); // taux d'intérêt 2.5%
        ce.calculInteret(); // Ajoute 2.5% au solde
        System.out.println(ce);

        System.out.println("\n=== Test Compte Payant ===");
        ComptePayant cp = new ComptePayant(1000);
        cp.verser(100);  // Frais de 5%
        cp.retirer(50);  // Frais de 5%
        System.out.println(cp);
    }
}