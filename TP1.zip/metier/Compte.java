package metier;

public class Compte {
    private int code;
    protected float solde;
    private static int compteur = 0;

    public Compte(float s) {
        compteur++;
        this.code = compteur;
        this.solde = s;
    }

    public void verser(float mt) {
        solde += mt;
    }

    public void retirer(float mt) {
        solde -= mt;
    }
    public int getCode() {
        return code;
    }

    public float getSolde() {
        return solde;
    }

    @Override
    public String toString() {
        return "Code=" + code + " Solde=" + solde;
    }
}
