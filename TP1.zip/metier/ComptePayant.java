package metier;

public class ComptePayant extends Compte {

    public ComptePayant(float s) {
        super(s);
    }

    @Override
    public void verser(float mt) {
        float frais = mt * 0.05f;
        super.verser(mt - frais);
    }

    @Override
    public void retirer(float mt) {
        float frais = mt * 0.05f;
        super.retirer(mt + frais);
    }

    @Override
    public String toString() {
        return super.toString() + " (Compte Payant - frais 5%)";
    }
}
