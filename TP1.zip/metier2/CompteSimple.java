package metier2;

import metier2.Compte;

public class CompteSimple extends Compte {
    private float decouvert;

    public CompteSimple(float s, float decouvert) {
        super(s);
        this.decouvert = decouvert;
    }

    @Override
    public void verser(float mt) {
        solde += mt;
    }

    @Override
    public void retirer(float mt) {
        if (solde - mt >= -decouvert) {
            solde -= mt;
            System.out.println("Retrait fait");
        } else {
            System.out.println("Impossible de retirer");
        }
    }

    @Override
    public String toString() {
        return "Code=" + getCode() + " Solde=" + getSolde() + " Découvert=" + decouvert;
    }
}
