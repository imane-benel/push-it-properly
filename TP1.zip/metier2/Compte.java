package metier2;

public abstract class Compte {
    private int code;
    protected float solde;
    private static int compteur = 0;

    public Compte(float s) {
        compteur++;
        this.code = compteur;
        this.solde = s;
    }

    public int getCode() {
        return code;
    }

    public float getSolde() {
        return solde;
    }

    public abstract void verser(float mt);

    public abstract void retirer(float mt);

    @Override
    public abstract String toString();
}


