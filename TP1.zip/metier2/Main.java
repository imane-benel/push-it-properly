package metier2;

import metier2.ComptePayant;
import metier2.CompteSimple;
import metier2.CpmteEpargne;

public class Main {
    public static void main(String[] args) {
        // Création d'un compte simple avec un découvert autorisé
        CompteSimple cs = new CompteSimple(1000, 200);
        cs.verser(500);
        cs.retirer(1400); // Retrait possible
        cs.retirer(200);  // Retrait impossible
        System.out.println(cs);

        System.out.println("--------------------------------");

        // Création d'un compte payant (avec 5% de frais)
        ComptePayant cp = new ComptePayant(2000);
        cp.verser(1000); // Ajoute 950 après frais
        cp.retirer(500); // Retire 525 après frais
        System.out.println(cp);

        System.out.println("--------------------------------");

        // Création d'un compte épargne avec taux d’intérêt
        CpmteEpargne ce = new CpmteEpargne(3000, 3.5f);
        ce.calculInteret(); // Ajoute les intérêts
        ce.retirer(1000);
        System.out.println(ce);
        Payment pa = new Payment(10, ce);
        System.out.println(ce);

    }
}
