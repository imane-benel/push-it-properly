package metier2;

import metier2.Compte;

public class CpmteEpargne extends Compte {
    private float tauxInteret;

    public CpmteEpargne(float s, float tauxInteret) {
        super(s);
        this.tauxInteret = tauxInteret;
    }

    public void calculInteret() {
        float interet = getSolde() * tauxInteret / 100;
        verser(interet);
    }

    @Override
    public void verser(float mt) {
        solde += mt;
    }

    @Override
    public void retirer(float mt) {
        if (mt <= solde) {
            solde -= mt;
        } else {
            System.out.println("Fonds insuffisants pour le retrait.");
        }
    }

    @Override
    public String toString() {
        return "Code=" + getCode() + " Solde=" + getSolde() + " Taux d'intérêt=" + tauxInteret + "%";
    }
}
