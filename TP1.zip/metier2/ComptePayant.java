package metier2;

public class ComptePayant extends Compte {

    public ComptePayant(float s) {
        super(s);
    }

    @Override
    public void verser(float mt) {
        float frais = mt * 0.05f;
        solde += (mt - frais);
    }

    @Override
    public void retirer(float mt) {
        float frais = mt * 0.05f;
        solde -= (mt + frais);
    }

    @Override
    public String toString() {
        return "Code=" + getCode() + " Solde=" + getSolde() + " (Compte Payant - frais 5%)";
    }
}
