package metier2;

public class Payment {
    Compte compte;
    public float montant;
    public Payment(float montant,Compte compte ) {

            this.montant=montant;
            this.compte=compte;
            this.compte.retirer(montant);

    }
}
