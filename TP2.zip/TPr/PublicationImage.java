package TPr;


 class PublicationImage extends Publication{
    String description;

    public PublicationImage(String id, String name, String contenu, String datePUb,String description) {
        super(id, name, contenu, datePUb);
        this.description = description;

    }
    boolean PotentiellementFake() {
        for (String mot : mots){
            if(description.toLowerCase().contains(mot)|| contenu.toLowerCase().contains(mot)){
                return true;
            }
          }
        return false;
    }
     public void afficher() {
         super.afficher();
         System.out.println("Description : " + description);
     }
 }

