package TPr;
import java.util.ArrayList;

 abstract class Publication {
     public String id;
     public String name;
     public String contenu;
     public String datePUb;
     public ArrayList<String> mots = new ArrayList<>();

     public Publication(String id, String name, String contenu, String datePUb) {
         this.id = id;
         this.name = name;
         this.contenu = contenu;
         this.datePUb = datePUb;
         mots.add("complot");
         mots.add("virus créé");
         mots.add("puce 5G");
         mots.add("fake");
         mots.add("manipulation");
         mots.add("mensonge");

     }
     abstract boolean PotentiellementFake();
     public void afficher() {
         System.out.println("l'id de la publication " + id);
         System.out.println("le nom de son auteur " + name);
         System.out.println("le contenu de la publication " +contenu );
         System.out.println("Sa date de publication " + datePUb);


     }

 }

