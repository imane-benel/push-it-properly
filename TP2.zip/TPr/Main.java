package TPr;

public class Main {
        public static void main(String[] args) {
            PublicationTexte P1 = new PublicationTexte("A","Ahmed Sefrioui","cette publication contient le texte des gens fake","2004");
            PublicationTexte P2 = new PublicationTexte("B","Aicha loulita","ce texte me permet de s'exprimer...","2022");

            PublicationImage P3 = new PublicationImage("C","John nibu","c'est une image mensonge","2014","image");
            PublicationVideo P4 = new PublicationVideo("C","Ahmed Sefrioui","c'est une video des enfants qui jouent...","2023","2min","video funny");
            PublicationImage P5 = new PublicationImage("C","Aicha loulita","c'est une image normale","2010","image");

            System.out.println("__l'ajout des publications dans la plateforme__");
            Plateforme pf = new Plateforme();
            pf.ajouterPublication(P1);
            pf.ajouterPublication(P2);
            pf.ajouterPublication(P3);
            pf.ajouterPublication(P4);
            pf.ajouterPublication(P5);
            System.out.println("C'est fait");
            System.out.println("__l'affichage de toutes les publications__");
            pf.afficherToutesPublications();
            System.out.println("__l'affichage des  publications douteuses__");
            pf.afficherPublicationsDouteuses();

            System.out.println("__l'affichage des  publications par l'auteur Ahmed Sefrioui __");
            pf.afficherParAuteur("Ahmed Sefrioui");


        }
        }
