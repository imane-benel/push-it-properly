package TPr;


class PublicationVideo extends Publication{
        String duree;
        String titre;

    public PublicationVideo(String id, String name, String contenu, String datePUb, String duree, String titre) {
        super(id, name, contenu, datePUb);
        this.duree = duree;
        this.titre = titre;

    }
    boolean PotentiellementFake() {
        for (String mot : mots){
            if( contenu.toLowerCase().contains(mot)||titre.toLowerCase().contains(mot)){
                return true;
            }
        }
        return false;
    }
    public void afficher() {
        super.afficher();
        System.out.println("la durée de la video " +duree );
        System.out.println("la titre de la video " +titre );


    }
}
