package TPr;


class PublicationTexte extends Publication{


    public PublicationTexte(String id, String name, String contenu, String datePUb) {
        super(id, name, contenu, datePUb);


    }
    boolean PotentiellementFake() {
        for (String mot : mots){
            if( contenu.toLowerCase().contains(mot)){
                return true;
            }
        }
        return false;
    }
    public void afficher() {
        super.afficher();

    }
}

