package TPr;
import java.util.ArrayList;
import java.util.HashMap;


public class Plateforme {
    ArrayList<Publication> publications;
    HashMap<String, ArrayList<Publication>> pubParAuteur;

    public Plateforme() {
        publications = new ArrayList<>();
        pubParAuteur = new HashMap<>();
    }

    void ajouterPublication(Publication p) {
        publications.add(p);
        pubParAuteur.putIfAbsent(p.name,new ArrayList<>());
        pubParAuteur.get(p.name).add(p);
    }

    void afficherToutesPublications() {
        for (Publication p : publications) {
            p.afficher();
        }
    }

    void afficherPublicationsDouteuses() {
        for (Publication p : publications) {
            if (p.PotentiellementFake()) {
                p.afficher();
            }
        }
        System.out.println("Aucune Publication détéctée comme fake ");
    }

    void afficherParAuteur(String auteur) {
        if (pubParAuteur.containsKey(auteur)) {
            ArrayList<Publication> pubs = pubParAuteur.get(auteur);
            for (Publication p : pubs) {
                p.afficher();
            }
        } else {
            System.out.println("Aucune publication trouvée pour l’auteur : " + auteur);
        }
    }
}




